package de.bmsapp.niko.oscillation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

public class RecordActivity extends AppCompatActivity implements SensorEventListener{

    private SensorManager sensorManager;
    private Sensor senAccelerometer;
    private Sensor senGyroscope;
    private Sensor senTemperatur;
    private boolean isRecording = false;

    private double THRESHOLD = 0.05;
    private double FRAMERATE = 50;

    TextView tvAccX;
    TextView tvAccY;
    TextView tvAccZ;
    TextView tvSpeedX;
    TextView tvSpeedY;
    TextView tvSpeedZ;
    TextView tvDistanceX;
    TextView tvDistanceY;
    TextView tvDistanceZ;
    TextView tvDistance;
    Button recordButton;
    SeekBar sbLowPass;
    SeekBar sbSaveRate;
    TextView timeDiff;
    Boolean firstRun = true;

    ArrayList <Double> dt,x,y,z;
    ArrayList <Double> vx,vy,vz,v;
    ArrayList <Double> dx, dy,dz,d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        senAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        senGyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        senTemperatur = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        lastUpdate = System.currentTimeMillis();

        dt = new ArrayList<>();
        x = new ArrayList<>();
        y = new ArrayList<>();
        z = new ArrayList<>();
        vx = new ArrayList<>();
        vy = new ArrayList<>();
        vz = new ArrayList<>();
        v = new ArrayList<>();
        dx = new ArrayList<>();
        dy = new ArrayList<>();
        dz = new ArrayList<>();
        d = new ArrayList<>();
        x.add(0.0);
        y.add(0.0);
        z.add(0.0);
        vx.add(0.0);
        vy.add(0.0);
        vz.add(0.0);
        dx.add(0.0);
        dy.add(0.0);
        dz.add(0.0);
        d.add(0.0);
        dt.add(0.0);

        tvAccX = findViewById(R.id.accX);
        tvAccY = findViewById(R.id.accY);
        tvAccZ = findViewById(R.id.accZ);
        tvSpeedX = findViewById(R.id.speedX);
        tvSpeedY = findViewById(R.id.speedY);
        tvSpeedZ = findViewById(R.id.speedZ);
        tvDistanceX = findViewById(R.id.distanceX);
        tvDistanceY = findViewById(R.id.distanceY);
        tvDistanceZ = findViewById(R.id.distanceZ);
        tvDistance = findViewById(R.id.distance);
        recordButton = findViewById(R.id.button);
        timeDiff = findViewById(R.id.timeDiff);

        sbLowPass = findViewById(R.id.sb_LowPassThreshold);
        sbLowPass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.i("NiKo","THRESHOLD Progress: " + (double)progress/1000);
                THRESHOLD = (double) progress/10000;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sbSaveRate = findViewById(R.id.sb_SaveFramerate);
        sbSaveRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                FRAMERATE = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void Record(View v){
        if(isRecording){
            sensorManager.unregisterListener(this);
            recordButton.setText("Start recording");
            isRecording = false;
            firstRun = true;
        }else{
            sensorManager.registerListener(this, senAccelerometer,SensorManager.SENSOR_DELAY_FASTEST);
            recordButton.setText("Stop recording");
            isRecording = true;
        }
    }

    public void resetValues(View btn){
        dt = new ArrayList<>();
        x = new ArrayList<>();
        y = new ArrayList<>();
        z = new ArrayList<>();
        vx = new ArrayList<>();
        vy = new ArrayList<>();
        vz = new ArrayList<>();
        v = new ArrayList<>();
        dx = new ArrayList<>();
        dy = new ArrayList<>();
        dz = new ArrayList<>();
        d = new ArrayList<>();
        x.add(0.0);
        y.add(0.0);
        z.add(0.0);
        vx.add(0.0);
        vy.add(0.0);
        vz.add(0.0);
        dx.add(0.0);
        dy.add(0.0);
        dz.add(0.0);
        d.add(0.0);
        dt.add(0.0);
        firstRun = true;
    }


    private long lastUpdate = 0;

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;

        if (firstRun){
            lastUpdate = System.currentTimeMillis();
            firstRun = false;
        }

        if(sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){

        long curTime = System.currentTimeMillis();
            Log.i("NiKo", "CurTIme: " + curTime + "; THRESHOLD: " + THRESHOLD);
        if(Math.abs(event.values[0]) > THRESHOLD &&
                Math.abs(event.values[1])>THRESHOLD &&
                Math.abs(event.values[2]) > THRESHOLD) {

            dt.add((double) (curTime - lastUpdate) / 1000);

            x.add((double) event.values[0]);
            y.add((double) event.values[1]);
            z.add((double) event.values[2]);
            vx.add(vx.get(vx.size() - 1) + x.get(x.size() - 1) * dt.get(dt.size() - 1));
            vy.add(vy.get(vy.size() - 1) + y.get(y.size() - 1) * dt.get(dt.size() - 1));
            vz.add(vz.get(vz.size() - 1) + z.get(z.size() - 1) * dt.get(dt.size() - 1));
            dx.add(dx.get(dx.size()-1)+ vx.get(vx.size() - 1) * dt.get(dt.size() - 1) + (x.get(x.size() - 1) / 2) * Math.pow(dt.get(dt.size() - 1), 2));
            dy.add(dy.get(dy.size()-1)+ vy.get(vy.size() - 1) * dt.get(dt.size() - 1) + (y.get(y.size() - 1) / 2) * Math.pow(dt.get(dt.size() - 1), 2));
            dz.add(dz.get(dz.size()-1)+ vz.get(vz.size() - 1) * dt.get(dt.size() - 1) + (z.get(z.size() - 1) / 2) * Math.pow(dt.get(dt.size() - 1), 2));

            d.add(d.get(d.size()-1)+ Math.sqrt(Math.pow(dx.get(dx.size() - 1), 2) + Math.pow(dy.get(dy.size() - 1), 2) + Math.pow(dz.get(dz.size() - 1), 2)));
        }

            double diffTime = curTime - lastUpdate;
            Log.i("NiKo", "DiffTime: " + diffTime + "; LastUpdate: " + lastUpdate + "; CurTime: " + curTime + "; FRAMERATE: " + FRAMERATE);
            if(diffTime > FRAMERATE){
                lastUpdate = curTime;

                tvAccX.setText(String.valueOf(y.get(y.size()-1)));
                tvAccY.setText(String.valueOf(y.get(y.size()-1)));
                tvAccZ.setText(String.valueOf(z.get(z.size()-1)));
                tvSpeedX.setText(String.valueOf(vx.get(vx.size()-1)));
                tvSpeedY.setText(String.valueOf(vx.get(vy.size()-1)));
                tvSpeedZ.setText(String.valueOf(vz.get(vz.size()-1)));
                tvDistanceX.setText(String.valueOf(dx.get(dx.size()-1)));
                tvDistanceY.setText(String.valueOf(dy.get(dy.size()-1)));
                tvDistanceZ.setText(String.valueOf(dz.get(dz.size()-1)));
                tvDistance.setText(String.valueOf(d.get(d.size()-1)));
                timeDiff.setText(String.valueOf(dt.get(d.size()-1)));

            }


        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
